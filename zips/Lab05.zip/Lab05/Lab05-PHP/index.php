<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Normal HTML Content...</h1>
        <?php
            echo "<h3>Content inside PHP code...</h3>";
            echo "<hr />";
            echo phpinfo();
        ?>
    </body>
</html>
