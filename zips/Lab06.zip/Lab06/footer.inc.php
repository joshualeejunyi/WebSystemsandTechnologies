<footer class="container">
    <p><em>Copyright &copy; 2020 World of Pets Pte. Ltd.</em></p>
</footer>