<?php
    include "head.inc.php";
?>

<body>
    <?php
        include "nav.inc.php";
    ?>
    
    <main class="container">
        <div class='jumbotron text-center'>
            <h4 class='display-4'>Welcome to your account!</h4>
        </div>
    </main>
</body>
        